#!/bin/bash

# Install dependencies if not already installed
echo "Installing Python dependencies..."
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# Set environment variables for Azure
export PORT=${PORT:-8000}

# Start the application
echo "Starting OptimAIze Teams Bot on port $PORT..."
python -m uvicorn app:app --host 0.0.0.0 --port $PORT